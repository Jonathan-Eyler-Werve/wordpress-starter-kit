Reverie Child Theme Package
=============

A child theme package for Reverie.

Learn about how to set up a child theme for Reverie.

[http://themefortress.com/reverie-child-theme-github/](http://themefortress.com/reverie-child-theme-github/)
