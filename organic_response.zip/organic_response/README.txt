Organic Response Theme v1.2
http://www.organicthemes.com

INSTALL: 
1. Upload the theme by navigating to Appearance > Themes > Install Themes within the WordPress admin. Select the theme zip file to upload.
2. Activate the theme after uploading.
3. Configure and save the theme options within Appearance > Theme Options. You may be required to install the Options Framework plugin if you have not already done so.

CHANGELOG v1.0.1:
- Fixed jQuery conflict with WooCommerce variable products in functions-meta.php

CHANGELOG v1.0.2:
- Style updates for iPad
- Mobile drop down menu added

CHANGELOG v1.0.3:
- Updated theme description
- Updated mobile drop down menu

CHANGELOG v1.0.4:
- Updated options description for social links

CHANGELOG v1.0.5:
- Removed thumb.php call from slideshow post background custom field
- Updated mobile menu so it displays the current page

CHANGELOG v1.0.6:
- Replaced wpautop filter function in shortcodes.php

CHANGELOG v1.1:
- Considerable debugging and updates
- Updated scripts
- Updated font awesome
- Retina optimization tweaks
- Replaced mobile menu
- Updated shortcodes
- Added 3 column page template
- Removed PressTrends
- Declared WooCommerce support
- Updated featured video
- Featured slideshow updates

CHANGELOG v1.1.1:
- Mobile style tweaks

CHANGELOG v1.1.2:
- Featured slider headline style updates

CHANGELOG v1.1.2.1:
- Added font italic styling for em

CHANGELOG v1.2:
- WPML compatibility
- Removed retina.js
- Updated portfolio page template
- Style tweaks
- Debugging